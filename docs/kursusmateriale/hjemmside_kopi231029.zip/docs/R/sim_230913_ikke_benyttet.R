set.seed(2023)

### population

n_pop <- 10000 # populationsstørrelse, skal være stor
# my_pop <- seq(0, 1, length = n_pop) # ligefordelingen på 0-1
# my_pop <- rnorm(n_pop, mean = 0, sd = 1) # standardnormalfordelingen

hist(my_pop, prob = T)

### stikprøve

n <- 1000 # antal stikprøver: i praksis altid 1
my_draw1 <- sample(my_pop, size = n, replace = TRUE)
my_draw2 <- sample(my_pop, size = n, replace = TRUE)
my_draw3 <- sample(my_pop, size = n, replace = TRUE)
my_draw4 <- sample(my_pop, size = n, replace = TRUE)
my_draw5 <- sample(my_pop, size = n, replace = TRUE)
my_draw6 <- sample(my_pop, size = n, replace = TRUE)
my_draw7 <- sample(my_pop, size = n, replace = TRUE)
my_draw8 <- sample(my_pop, size = n, replace = TRUE)
my_draw9 <- sample(my_pop, size = n, replace = TRUE)
my_draw10 <- sample(my_pop, size = n, replace = TRUE)

# histogram over en enkelt stikprøve af størrelse n
hist(my_draw1, prob = T)
qqnorm(my_draw1)

# gennemsnit hvis stikprøvestørrelse er 2
my_mean2 <- (my_draw1 + my_draw2) / 2
hist(my_mean2, prob = T)
qqnorm(my_mean2)

# gennemsnit hvis stikprøvestørrelse er 5
my_mean5 <- (my_draw1 + my_draw2 
             + my_draw3 + my_draw4 
             + my_draw5) / 5
hist(my_mean5, prob = T)
qqnorm(my_mean5)

# gennemsnit hvis stikprøvestørrelse er 10
my_mean10 <- (my_draw1 + my_draw2 
             + my_draw3 + my_draw4 
             + my_draw5 + my_draw6
             + my_draw7 + my_draw8
             + my_draw9 + my_draw10) / 10
hist(my_mean10, prob = T)
qqnorm(my_mean10)
