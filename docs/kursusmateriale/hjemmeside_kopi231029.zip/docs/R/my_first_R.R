x <- c(1, 2, 3)
x
# beregn gennemsnit af tallene i x
mean(x)
